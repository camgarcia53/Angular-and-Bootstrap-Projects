var userChoice = prompt("Do you like Coolie Girls?");
if (userChoice === "yes") {
	console.log("Hallelujah");
} else if(userChoice === "no") {
	console.log("BULLSHITTT");
} else {
	console.log("Its ok, WE know u Do");

};